package ProjetoSuaCesta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuaCestaApplicationTests {

	@Test
	void contextLoads() {
	}

}
